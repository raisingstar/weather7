[![devDependency Status](https://david-dm.org/nolimits4web/weather7-material/dev-status.svg)](https://david-dm.org/nolimits4web/weather7-material#info=devDependencies)
[![Flattr this git repo](http://api.flattr.com/button/flattr-badge-large.png)](https://flattr.com/submit/auto?user_id=nolimits4web&url=https://github.com/nolimits4web/weather7-material/&title=Weather7&language=JavaScript&tags=github&category=software)

# Weather7-Material

Weather7 is the simple weather webapp that demonstrates how easy to create fully functioning Android Material app with Framework7. With PhoneGap you can easily convert it to native Android app.
